# UVCC Parking Tickets – deploy

1. Push this folder to a GitHub repo (or use `netlify deploy --prod` from the Netlify CLI).
2. Netlify > Add new site > Import from Git > pick the repo. Build settings auto-read from netlify.toml.
3. Site settings > Environment variables > add TEAM_PIN = (your PIN). Redeploy.
4. Open the site, enter the PIN. Done.

Note: dragging the built folder onto Netlify Drop will NOT work – it skips the serverless function, so saving tickets fails.
