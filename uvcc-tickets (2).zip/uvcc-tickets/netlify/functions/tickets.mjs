import { getStore } from "@netlify/blobs";

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

export default async (req) => {
  const pin = process.env.TEAM_PIN;
  if (!pin) return json({ error: "Server not configured (TEAM_PIN missing)" }, 500);
  if (req.headers.get("x-team-pin") !== pin) return json({ error: "Unauthorized" }, 401);

  const store = getStore("tickets");

  if (req.method === "GET") {
    const { blobs } = await store.list();
    const keys = blobs.map((b) => b.key).sort().reverse().slice(0, 100);
    const items = await Promise.all(keys.map((k) => store.get(k, { type: "json" })));
    return json(items.filter(Boolean));
  }

  if (req.method === "POST") {
    let b;
    try { b = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
    const clean = (v, n) => String(v ?? "").trim().slice(0, n);
    const ticket = {
      employee: clean(b.employee, 80),
      plate: clean(b.plate, 12).toUpperCase(),
      description: clean(b.description, 120),
      time: new Date().toISOString(),
    };
    if (!ticket.employee || !ticket.plate || !ticket.description) return json({ error: "All fields required" }, 400);
    const key = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    await store.setJSON(key, ticket);
    return json(ticket, 201);
  }

  return json({ error: "Method not allowed" }, 405);
};

export const config = { path: "/api/tickets" };
