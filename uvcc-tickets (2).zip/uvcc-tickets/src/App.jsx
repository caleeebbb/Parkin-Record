import { useState, useEffect } from "react";

const MONO = "'Space Mono', monospace";
const API = "/api/tickets";

async function api(pin, method = "GET", body) {
  const res = await fetch(API, {
    method,
    headers: { "Content-Type": "application/json", "x-team-pin": pin },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) throw new Error("AUTH");
  if (!res.ok) throw new Error("FAIL");
  return res.json();
}

function Row({ label, value, last }) {
  return (
    <div style={{ paddingBottom: 10, marginBottom: 10, borderBottom: last ? "none" : "1px solid #1e293b" }}>
      <div style={{ color: "#475569", fontSize: 10, fontFamily: MONO, letterSpacing: 2, marginBottom: 2 }}>{label}</div>
      <div style={{ color: "#f8fafc", fontSize: 15 }}>{value}</div>
    </div>
  );
}

function ConfirmScreen({ ticket, onNew }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "70vh", textAlign: "center", padding: 24 }}>
      <div style={{ fontSize: 56, marginBottom: 16 }}>✅</div>
      <div style={{ fontFamily: MONO, color: "#86efac", fontSize: 13, letterSpacing: 2, marginBottom: 8 }}>TICKET LOGGED</div>
      <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 12, padding: 20, width: "100%", maxWidth: 360, textAlign: "left", marginBottom: 24 }}>
        <Row label="EMPLOYEE" value={ticket.employee} />
        <Row label="PLATE" value={ticket.plate} />
        <Row label="VEHICLE" value={ticket.description} />
        <Row label="TIME" value={new Date(ticket.time).toLocaleString()} last />
      </div>
      <button onClick={onNew} style={{ background: "#6366f1", border: "none", color: "#fff", borderRadius: 10, padding: "14px 32px", cursor: "pointer", fontFamily: MONO, fontSize: 14, fontWeight: 700, letterSpacing: 1, width: "100%", maxWidth: 360 }}>
        + ISSUE ANOTHER TICKET
      </button>
    </div>
  );
}

const inputStyle = {
  width: "100%", background: "#0f172a", border: "1px solid #1e293b", color: "#f8fafc",
  borderRadius: 10, padding: "16px 14px", fontSize: 17, outline: "none", boxSizing: "border-box",
  transition: "border-color 0.15s", fontFamily: "system-ui, sans-serif",
};
const labelStyle = { color: "#94a3b8", fontSize: 13, fontWeight: 600, display: "block", marginBottom: 8 };
const focusOn = (e) => (e.target.style.borderColor = "#6366f1");
const focusOff = (e) => (e.target.style.borderColor = "#1e293b");

function PinGate({ onPin, msg }) {
  const [v, setV] = useState("");
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 40 }}>
      <label style={labelStyle}>Team PIN</label>
      <input style={inputStyle} type="password" inputMode="numeric" value={v} onChange={(e) => setV(e.target.value)}
        onFocus={focusOn} onBlur={focusOff} placeholder="Enter PIN" autoComplete="off" />
      {msg && <div style={{ color: "#fca5a5", fontSize: 13 }}>{msg}</div>}
      <button onClick={() => v && onPin(v)} style={{ background: "#6366f1", border: "none", color: "#fff", borderRadius: 10, padding: "16px 0", cursor: "pointer", fontFamily: MONO, fontSize: 15, fontWeight: 700, letterSpacing: 1 }}>
        UNLOCK
      </button>
    </div>
  );
}

export default function App() {
  const [pin, setPin] = useState(() => localStorage.getItem("uvcc_pin") || "");
  const [pinMsg, setPinMsg] = useState("");
  const [employee, setEmployee] = useState(() => localStorage.getItem("uvcc_emp") || "");
  const [plate, setPlate] = useState("");
  const [description, setDescription] = useState("");
  const [submitted, setSubmitted] = useState(null);
  const [showLog, setShowLog] = useState(false);
  const [log, setLog] = useState([]);
  const [loadingLog, setLoadingLog] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const canSubmit = employee.trim() && plate.trim() && description.trim();

  const lock = (msg) => { localStorage.removeItem("uvcc_pin"); setPin(""); setPinMsg(msg); };

  const tryPin = async (p) => {
    try {
      await api(p);
      localStorage.setItem("uvcc_pin", p);
      setPinMsg("");
      setPin(p);
    } catch (e) {
      setPinMsg(e.message === "AUTH" ? "Wrong PIN." : "Can't reach server. Try again.");
    }
  };

  const loadLog = async () => {
    setLoadingLog(true);
    try { setLog(await api(pin)); }
    catch (e) { if (e.message === "AUTH") lock("PIN changed. Re-enter."); else setLog([]); }
    setLoadingLog(false);
  };

  useEffect(() => { if (showLog && pin) loadLog(); }, [showLog]);

  const handleSubmit = async () => {
    if (!canSubmit || saving) return;
    setSaving(true);
    setError("");
    try {
      const t = await api(pin, "POST", { employee, plate, description });
      localStorage.setItem("uvcc_emp", employee.trim());
      setSubmitted(t);
      setPlate("");
      setDescription("");
    } catch (e) {
      if (e.message === "AUTH") lock("PIN changed. Re-enter.");
      else setError("Couldn't save the ticket. Check connection and try again.");
    }
    setSaving(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#020617", color: "#f8fafc", padding: "20px 16px 40px", fontFamily: "system-ui, sans-serif" }}>
      <div style={{ maxWidth: 420, margin: "0 auto" }}>
        <div style={{ marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontFamily: MONO, color: "#475569", fontSize: 10, letterSpacing: 4, marginBottom: 4 }}>UVCC PARKING</div>
            <h1 style={{ margin: 0, fontFamily: MONO, fontSize: 24, fontWeight: 700, letterSpacing: -1 }}>Issue a Ticket</h1>
          </div>
          {pin && (
            <button onClick={() => setShowLog((s) => !s)} style={{ background: showLog ? "#6366f1" : "transparent", border: "1px solid #1e293b", color: showLog ? "#fff" : "#94a3b8", borderRadius: 8, padding: "8px 12px", cursor: "pointer", fontFamily: MONO, fontSize: 11, letterSpacing: 1, whiteSpace: "nowrap" }}>
              {showLog ? "✕ CLOSE" : "☰ LOG"}
            </button>
          )}
        </div>

        {!pin ? (
          <PinGate onPin={tryPin} msg={pinMsg} />
        ) : showLog ? (
          <div style={{ background: "#0f172a", border: "1px solid #1e293b", borderRadius: 12, padding: 16 }}>
            <div style={{ fontFamily: MONO, color: "#475569", fontSize: 10, letterSpacing: 3, marginBottom: 12 }}>
              RECENT TICKETS {loadingLog ? "· loading..." : `· ${log.length}`}
            </div>
            {!loadingLog && log.length === 0 && <div style={{ color: "#475569", fontSize: 13, padding: "12px 0" }}>No tickets logged yet.</div>}
            {log.map((t, i) => (
              <div key={i} style={{ padding: "10px 0", borderBottom: i < log.length - 1 ? "1px solid #1e293b" : "none" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <span style={{ fontFamily: MONO, color: "#a5b4fc", fontSize: 14, fontWeight: 700 }}>{t.plate}</span>
                  <span style={{ color: "#475569", fontSize: 11 }}>{new Date(t.time).toLocaleString()}</span>
                </div>
                <div style={{ color: "#e2e8f0", fontSize: 13, marginTop: 2 }}>{t.description}</div>
                <div style={{ color: "#64748b", fontSize: 12, marginTop: 1 }}>by {t.employee}</div>
              </div>
            ))}
          </div>
        ) : submitted ? (
          <ConfirmScreen ticket={submitted} onNew={() => setSubmitted(null)} />
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            <div>
              <label style={labelStyle}>Employee Name</label>
              <input style={inputStyle} value={employee} onChange={(e) => setEmployee(e.target.value)} placeholder="Your name" onFocus={focusOn} onBlur={focusOff} autoComplete="off" />
            </div>
            <div>
              <label style={labelStyle}>License Plate Number</label>
              <input style={{ ...inputStyle, fontFamily: MONO, letterSpacing: 1, textTransform: "uppercase" }} value={plate} onChange={(e) => setPlate(e.target.value)} placeholder="ABC 1234" onFocus={focusOn} onBlur={focusOff} autoComplete="off" />
            </div>
            <div>
              <label style={labelStyle}>Vehicle — Make / Model / Color</label>
              <input style={inputStyle} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Silver Honda Civic" onFocus={focusOn} onBlur={focusOff} autoComplete="off" />
            </div>
            {error && <div style={{ color: "#fca5a5", fontSize: 13, background: "#450a0a", border: "1px solid #7f1d1d", borderRadius: 8, padding: "10px 12px" }}>{error}</div>}
            <button onClick={handleSubmit} disabled={!canSubmit || saving} style={{ marginTop: 6, background: canSubmit && !saving ? "#6366f1" : "#1e293b", border: "none", color: canSubmit && !saving ? "#fff" : "#475569", borderRadius: 10, padding: "16px 0", cursor: canSubmit && !saving ? "pointer" : "not-allowed", fontFamily: MONO, fontSize: 15, fontWeight: 700, letterSpacing: 1, transition: "all 0.15s" }}>
              {saving ? "SAVING..." : "SUBMIT TICKET"}
            </button>
            <div style={{ color: "#475569", fontSize: 12, textAlign: "center", marginTop: 4 }}>
              All fields required. Tickets are saved automatically and visible to the team in the log.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
